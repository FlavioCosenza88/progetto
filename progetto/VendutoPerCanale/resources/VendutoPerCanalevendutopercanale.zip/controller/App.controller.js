sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("VendutoPerCanale.vendutopercanale.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map