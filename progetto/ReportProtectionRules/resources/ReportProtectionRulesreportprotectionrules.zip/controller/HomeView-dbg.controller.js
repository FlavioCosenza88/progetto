sap.ui.define([
    "./Base.controller",
    "sap/m/MessageBox",
    "sap/ui/model/Filter"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, MessageBox, Filter) {
        "use strict";

        return Controller.extend("ReportProtectionRules.reportprotectionrules.controller.HomeView", {
            onInit: function () {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.getRoute("RouteHomeView").attachPatternMatched(this._onObjectMatched, this);
            },
            _onObjectMatched: function (oEvent) {


            },
            onExportCurrentPROTECTIONRULES_LOWLEVEL: function () {

                // Open the busy dialog

                //console.log(aFilteredDatasetExport);
                //let aDataset = []


                var oBusyDialog = new sap.m.BusyDialog({
                    title: "Export in corso",
                    text: "L'operazione potrebbe richiedere qualche secondo..."
                });
                oBusyDialog.open();
                var filters = this.getView().byId("smartFilterPROTECTIONRULES_LOWLEVEL").getFilterData()
                var aFilters = [];
                for (var i in filters) {
                    if (filters[i]) {
                        var aQuery = filters[i].ranges
                        for (var obj of aQuery) {
                            aFilters.push(new Filter(i, obj.operation, obj.value1));
                        }
                    }
                }

                let oTempModel = this.getView().getModel("temp");
                let oModel = this.getView().getModel();
                oModel.read(`/PROTECTIONRULES_LOWLEVEL`, {
                    filters:aFilters,
                    success: function (data) {
                        oTempModel.setProperty("/PROTECTIONRULES_LOWLEVEL", data.results);
                        let aRowItems = oTempModel.getData().PROTECTIONRULES_LOWLEVEL.map((

                            { ARTICLE_DESCR, ARTICLE_ID, ARTICLE_IMG, BRAND, BRAND_ID, FAMILY, FAMILY_ID, GENDER, ID_REGOLA, PRODUCT_GROUP, QUANTITA_PROTETTA, QUANTITA_STOCK, RETAIL_PRICE, SALES_CHANNEL, SALES_CHANNEL_ID, SEASON, SEASON_YEAR, STORE_POINT, STORE_POINT_ID, VALIDO_A, VALIDO_DA, VALORE_STOCK_PROTETTO, WHOLESALE }
                        ) => (
                            { ARTICLE_DESCR, ARTICLE_ID, ARTICLE_IMG, BRAND, BRAND_ID, FAMILY, FAMILY_ID, GENDER, ID_REGOLA, PRODUCT_GROUP, QUANTITA_PROTETTA, QUANTITA_STOCK, RETAIL_PRICE, SALES_CHANNEL, SALES_CHANNEL_ID, SEASON, SEASON_YEAR, STORE_POINT, STORE_POINT_ID, VALIDO_A, VALIDO_DA, VALORE_STOCK_PROTETTO, WHOLESALE }
                        ));
        
                        var that = this
        
                        $.ajax({
        
                            url: that.getView().getModel("exportService").sServiceUrl + "/format_excel",
                            // url: "/export-oda/format_excel",
                            type: "POST",
                            data: JSON.stringify({ lineItems: aRowItems }),
                            contentType: "application/json; charset=utf-8",
                            responseType: "text",
                            success: function (data) {
                                //console.log(data)
                                //ar a=atob(JSON.stringify(data.value))
        
                                //application/vnd.ms-excel
                                let type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                                // let blob = new Blob([data.value], { aReadPromisestype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                                let excelBlob = that.b64toBlob(data.d.format_excel, type)
                                //  Create a URL for the Blob object
                                let url = URL.createObjectURL(excelBlob);
        
                                // Create a link and click it to start the download
                                let link = document.createElement('a');
                                link.href = url;
        
                                link.download = 'ProtectionRules.xlsx';
                                document.body.appendChild(link);
                                link.click();
                                document.body.removeChild(link);
                                oBusyDialog.close();
        
                            },
                            error: function (xhr, status, error) {
                                oBusyDialog.close();
                                MessageBox.error("Troppi dati da scaricare.Selezionare un range di date minore");
        
                            }
                        });
                    }.bind(this),
                    error: err => {
                        oBusyDialog.close();
                        MessageBox.error(err);
                    }

                });

               

            },
            onExportCurrentPROTECTIONRULES_HIGHLEVEL: function () {
                var oBusyDialog = new sap.m.BusyDialog({
                    title: "Export in corso",
                    text: "L'operazione potrebbe richiedere qualche secondo..."
                });
                // Open the busy dialog
                oBusyDialog.open();
                //console.log(aFilteredDatasetExport);
                //let aDataset = []
                if (!this._oTable) {
                    this._oTable = this.byId('TableRetails');
                }
                let oTable = this._oTable;

                let oRowBinding = oTable.getBinding('items');
                for (var obj of oTable.getBinding().oList) {
                    if (obj["PIECES_SOLD"])
                        obj["PIECES_SOLD"] = obj["PIECES_SOLD"].toString()
                }

                let aRowItems = oTable.getBinding().oList.map((
                    { BRAND, BRAND_ID, BUSINESSPARTNER, BUSINESSPARTNEREMAIL, BUSINESSPARTNERID, DOCUMENTPOSSALESPERSONID, DOCUMENTPOSSALESPERSON, DOCUMENTDATESTRING, COMPANY, COMPANYID, CURRENCY, DISCOUNT_APPLIED, DISCOUNT_PERCENTAGE, DOCUMENTDATE, DOCUMENTENTRY, DOCUMENTTYPE, FAMILY, FAMILY_ID, GENDER, IMAGE_URL, MATERIAL, MATERIAL_ID, PIECES_SOLD, REFERENCE_MATERIAL, REFERENCE_MATERIAL_ID, RETAIL_FULL_PRICE, SELL_OUT_PRICE, SKU_SEASON, STORE, STOREID, UM_WHOLESALE_PRICE, WHOLESALE_PRICE }
                ) => (
                    { BRAND, BRAND_ID, BUSINESSPARTNER, BUSINESSPARTNEREMAIL, BUSINESSPARTNERID, DOCUMENTPOSSALESPERSONID, DOCUMENTPOSSALESPERSON, DOCUMENTDATESTRING, COMPANY, COMPANYID, CURRENCY, DISCOUNT_APPLIED, DISCOUNT_PERCENTAGE, DOCUMENTDATE, DOCUMENTENTRY, DOCUMENTTYPE, FAMILY, FAMILY_ID, GENDER, IMAGE_URL, MATERIAL, MATERIAL_ID, PIECES_SOLD, REFERENCE_MATERIAL, REFERENCE_MATERIAL_ID, RETAIL_FULL_PRICE, SELL_OUT_PRICE, SKU_SEASON, STORE, STOREID, UM_WHOLESALE_PRICE, WHOLESALE_PRICE }));

                var that = this

                $.ajax({
                    url: that.getView().getModel("").sServiceUrl + "/format_excel",
                    //url: "/v2/export-oda/format_excel",
                    type: "POST",
                    data: JSON.stringify({ lineItems: aRowItems }),
                    contentType: "application/json; charset=utf-8",
                    responseType: "text",
                    success: function (data) {
                        //console.log(data)
                        //ar a=atob(JSON.stringify(data.value))

                        //application/vnd.ms-excel
                        let type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                        // let blob = new Blob([data.value], { aReadPromisestype: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                        let excelBlob = that.b64toBlob(data.d.format_excel, type)
                        //  Create a URL for the Blob object
                        let url = URL.createObjectURL(excelBlob);

                        // Create a link and click it to start the download
                        let link = document.createElement('a');
                        link.href = url;
                        var dateDa = that.byId("dateRange").getDateValue()
                        var dateA = that.byId("dateRange").getSecondDateValue()
                        var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ pattern: "YYYY-MM-dd" });
                        var dataDaFormatted = dateFormat.format(dateDa);
                        var dataAFormatted = dateFormat.format(dateA);
                        link.download = 'RetailSales(' + dataDaFormatted + '/' + dataAFormatted + ').xlsx';
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        oBusyDialog.close();

                    },
                    error: function (xhr, status, error) {
                        oBusyDialog.close();
                        MessageBox.error("Troppi dati da scaricare.Selezionare un range di date minore");

                    }
                });


            },


            //Converte la response dell'ajax in blob in modo da poterla scaricare
            b64toBlob: function (b64Data, contentType, sliceSize) {
                contentType = contentType || '';
                sliceSize = sliceSize || 512;

                var byteCharacters = atob(b64Data);
                var byteArrays = [];

                for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                    var slice = byteCharacters.slice(offset, offset + sliceSize);

                    var byteNumbers = new Array(slice.length);
                    for (var i = 0; i < slice.length; i++) {
                        byteNumbers[i] = slice.charCodeAt(i);
                    }

                    var byteArray = new Uint8Array(byteNumbers);

                    byteArrays.push(byteArray);
                }

                var blob = new Blob(byteArrays, { type: contentType });
                return blob;
            },
            onSearch: function (oEvent) {

            }

        });
    });
