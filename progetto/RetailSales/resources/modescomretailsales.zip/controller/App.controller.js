sap.ui.define(["sap/ui/core/mvc/Controller"],function(e){"use strict";return e.extend("modes.com.retailsales.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map